package assn3;

/**
 * This class primarily controls just starting the game
 * 
 * @author Nathnaniel Churchill, Eric Olechovski, Michael Baumgartner, Dan Richmond
 *
 */
public class Driver {

	public static void main(String[] args) {
		// Start the game!
		Game game = new Game();
		game.startGame();

	}
}
